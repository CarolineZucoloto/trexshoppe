# T-Rex-Game
The classic Google's Game. I did it in JavaScript and it's also adaptaded to mobile.

![trex](https://user-images.githubusercontent.com/42698693/177221953-e6f1c8fa-367f-4c06-a3d1-9c3ec093fc7f.PNG)
